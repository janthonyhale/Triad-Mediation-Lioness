<?php
include('_projectID.php');
include(PATH . "basis/common.php");
$_SESSION['projectID'] = PROJECTID;
include('_stageNames.php');
include(PATH . "basis/controlpanel/control.php");

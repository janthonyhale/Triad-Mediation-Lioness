<?php
/**
 * Created by PhpStorm.
 * User: GIAMAT01
 * Date: 29.03.2019
 * Time: 13:28
 */
header('Location: _beginParticipant.php');
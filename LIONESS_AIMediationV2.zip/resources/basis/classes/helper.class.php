<?php
/**
 * Created by PhpStorm.
 * User: marcusgia
 * Date: 29.04.2019
 * Time: 08:03
 */

class helper {


    public static function errormessage($message) {


        return $message;

    }


}
<?php
include('_projectID.php');
include(PATH . "basis/common.php");
$_SESSION['projectID'] = PROJECTID;
include(PATH . "basis/participant/register.php");

<?php
require('../common.php');
$playerNr = $_GET['playerNr'];
$_SESSION['testPlayerNr'] = $playerNr;
